import axios from 'axios'
import React ,{useState,useEffect} from 'react'
import { Link } from 'react-router-dom'

const Read = () => {
 const [Data, setData] = useState([])
 const [tabledark, setTabledark] = useState("")


    function getData(){
   axios
   .get("https://6408099b2f01352a8a8903f1.mockapi.io/Crud01")
  .then((res)=>{
    console.log(res.data);
    setData(res.data)
  })
}

function handele(id){
    axios.delete(`https://6408099b2f01352a8a8903f1.mockapi.io/Crud01/${id}`)
    .then(()=>{
        getData()
    })
}
useEffect(() => {
  getData();
}, [])

const setTolocalstorage=(id,Email,Name)=>{
    localStorage.setItem("id",id)
    localStorage.setItem("name",Name)
    localStorage.setItem("email",Email)

}

  return (
    <>
    <div className="form-check form-switch">
  <input className="form-check-input" type="checkbox" role="switch" onClick={
    ()=>{
        if(tabledark === "table-dark")setTabledark("")
        else setTabledark("table-dark");
    }
  } />
</div>

  <div className="d-flex justify-content-between m-4" >
    <h2>All have a Post</h2>
    <Link to={"/"}>
    <button type="button" class="btn btn-primary">Create New Post </button>

    </Link>

    </div>
<table class={`table ${tabledark}`}>
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col"> Post Name</th>
      <th scope="col">Post Title</th>
      <th scope="col">Edit</th>
      <th scope="col">Delit</th>

    </tr>
  </thead>
  {
  
  Data.map((eachData)=>{
    return <>

    <tbody>
    <tr>
      <th scope="row">{eachData.id}</th>
      <Link to="/cument">
      <td onClick={()=>{

setTolocalstorage(
    eachData.id,
    eachData.Name,
   )

      }}>{eachData.Name}</td>

      </Link>
      <td>{eachData.Email}</td>
      <td>
        <Link to="/update">
        <button className='btn-success' onClick={()=>{
            setTolocalstorage(
             eachData.id,
             eachData.Name,
             eachData.Email
            )
        }}>Edit</button>

        </Link>
      </td>
      <td>
      <button className='btn-denger' onClick={()=>{handele(eachData.id)}}>Delate</button>

      </td>


    </tr>
    
  </tbody>
    
    </>
  })
  
  
  }

  


</table>



    </>
  )
}

export default Read
