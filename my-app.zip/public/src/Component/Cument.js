import axios from 'axios';
import React,{useEffect,useState} from 'react'
import {Link, useNavigate} from "react-router-dom"
import Read from "./Read";


const Update = () => {

    const history= useNavigate()

     const [id, setid] = useState(0);
     const [name, setname] = useState("");
     const [email, setemail] = useState("")
     const [Cument, setcument] = useState("")


  useEffect(() => {

    setid(localStorage.getItem("id"));
    setname(localStorage.getItem("email"));
    setemail(localStorage.getItem("name"));
    console.log(name)


  }, [])

  /*const setTolocalstorage=(id,Email,Name)=>{
    localStorage.setItem("id",id)
    localStorage.setItem("name",Name)
    localStorage.setItem("email",Email)

}*/
  
  const Dta = [""];
/*const ok=()=>{
  alert(valu)
}*/

const cument=(e)=>{

  let valu=document.getElementById("value").value;

  Dta.push(valu);

  e.preventDefault();

axios.put(`https://6408099b2f01352a8a8903f1.mockapi.io/Crud01/${id}`,{
    cument :Dta,

})
console.log("checked")

  
}
  return (
    <>
        <h2>Coment here this post</h2>
      <form>
      <div className="mb-3">
    <label for="exampleInputPassword1" className="form-label">Post Title</label>
    <input type="text"  id="Name"
    
    value={name}/>
  </div>
 

  <div className="mb-3">
    <label >Coment the Post</label>
    <input type="text" 
   // onChange={(e)=>{setcument(e.target.value)}} 
     id="value"/>
    <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div>
  </div>
  <Link to="/read">
  <button type="submit" className="btn btn-primary m-2" onClick={cument}>Coment</button>
  </Link>

  <Link to="/read">
  <button type="submit" className="btn btn-primary m-2" 
  >Back</button>
  </Link>

  <Link to="/showcument">
  <button type="submit" className="btn btn-primary m-2" 
  /*onClick= {()=>{
           /* setTolocalstorage(
              
            )
        }}*/
  >Show All the coment in this post</button>
  </Link>

</form>

    </>
  )
}

export default Update