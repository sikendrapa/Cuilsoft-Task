import axios from "axios";
import React, { useState } from 'react'
import {Link, useNavigate} from "react-router-dom"

const Create = () => {
    
    const [Name, setaName] = useState("");
    const [Email, setaEmail] = useState("")

    const history= useNavigate()

    const header={"Access-Control-Allow-Origion":"*"}
    const hsn=(e)=>{
        console.log("checked")
        e.preventDefault();
        axios.post("https://6408099b2f01352a8a8903f1.mockapi.io/Crud01",{
            Name: Name,
            Email: Email,
            header,
        })
        // history("/read");
        .then(()=>{
            history("/read")
        })
    }
    return (
    <>
    <div className="d-flex justify-content-between m-4" >
    <h2>Create a new Post</h2>
    <Link to={"./read"}>
    <button type="button" class="btn btn-primary">Show post</button>

    </Link>

    </div>
      <form>
      <div className="mb-3">
    <label for="exampleInputPassword1" className="form-label"> Post Name</label>
    <input type="text" className="form-control" id="Name" onChange={(e)=>{setaName(e.target.value)}}/>
  </div>
 

  <div className="mb-3">
    <label for="exampleInputEmail1" className="form-label">Post Title</label>
    <input type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" onChange={(e)=>{setaEmail(e.target.value)}}/>
    <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div>
  </div>
  <button type="submit" className="btn btn-primary" onClick={hsn}>Submit</button>
</form>

    </>
  )
}

export default Create
