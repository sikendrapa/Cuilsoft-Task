import axios from 'axios';
import React,{useEffect,useState} from 'react'
import {Link, useNavigate} from "react-router-dom"
import Read from "./Read";


const Update = () => {

    const history= useNavigate()

     const [id, setid] = useState(0);
     const [name, setname] = useState("");
     const [email, setemail] = useState("")

  useEffect(() => {

    setid(localStorage.getItem("id"));
    setname(localStorage.getItem("email"));
    setemail(localStorage.getItem("name"));
    console.log(name)


  }, [])
  
const hsnup=(e)=>{
  e.preventDefault();
        axios.put(`https://6408099b2f01352a8a8903f1.mockapi.io/Crud01/${id}`,{
        Name: name,
        Email: email,
         }).then(()=>{
            history("/read")
        })
}
  return (
    <>
        <h2>Update</h2>
      <form>
      <div className="mb-3">
    <label for="exampleInputPassword1" className="form-label">Post Name</label>
    <input type="text"  id="Name"
    onChange={(e)=>{setname(e.target.value)}} 
    value={name}/>
  </div>
 

  <div className="mb-3">
    <label >Post Deatil</label>
    <input type="text"
     onChange={(e)=>{setemail(e.target.value)}}
        value={email}
        />
    <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div>
  </div>
  <button type="submit" className="btn btn-primary m-2" 
  onClick={hsnup}
  >Update</button>
  <Link to="/read">
  <button type="submit" className="btn btn-primary m-2" 
  >Back</button>
  </Link>
</form>

    </>
  )
}

export default Update

/*import React from 'react'

const Update = () => {
  return (
    <div>
      <h1>dfgvx</h1>
    </div>
  )
}

export default Update
*/
