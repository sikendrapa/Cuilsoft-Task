/*import axios from 'axios'
import React ,{useState,useEffect} from 'react'
import { Link } from 'react-router-dom'

const Read = () => {
  
  const [id, setid] = useState(0);
  const [name, setname] = useState("");
  const [email, setemail] = useState("")
 const [Data, setData] = useState([])
 const [tabledark, setTabledark] = useState("")

 console.log(id)
    function getData(){
   axios
   .get(`https://6408099b2f01352a8a8903f1.mockapi.io/Crud01/${id}`)
  .then((res)=>{
    console.log(res.data);
    setData(res.data)
  })
}

function handele(id){
    axios.delete(`https://6408099b2f01352a8a8903f1.mockapi.io/Crud01/${id}`)
    .then(()=>{
        getData()
    })
}
useEffect(() => {
  setid(localStorage.getItem("id"));
    setname(localStorage.getItem("email"));
    setemail(localStorage.getItem("name"));
    console.log(name)
  getData();
}, [])

const setTolocalstorage=(id,Email,Name)=>{
    localStorage.setItem("id",id)
    localStorage.setItem("name",Name)
    localStorage.setItem("email",Email)

}

  return (
    <>
    <div className="form-check form-switch">
  <input className="form-check-input" type="checkbox" role="switch" onClick={
    ()=>{
        if(tabledark === "table-dark")setTabledark("")
        else setTabledark("table-dark");
    }
  } />
</div>

  <div className="d-flex justify-content-between m-4" >
    <h2>All have a cument in this particular post</h2>
    <Link to={"/"}>
    <button type="button" class="btn btn-primary">Create New Post </button>

    </Link>

    </div>
<table class={`table ${tabledark}`}>
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">jhk</th>
      <th scope="col">Post Title</th>
      <th scope="col">Edit</th>
      <th scope="col">Delit</th>

    </tr>
  </thead>
  {
  
  Data.map((eachData)=>{
    return <>

    <tbody>
    <tr>
      <th scope="row">{eachData.id}</th>
      <Link to="/cument">
      <td onClick={()=>{

setTolocalstorage(
    eachData.id,
    eachData.Name,
   )

      }}>{eachData.Name}</td>

      </Link>
      <td>{eachData.cument}</td>
      <td>
        <Link to="/update">
        <button className='btn-success' onClick={()=>{
            setTolocalstorage(
             eachData.id,
             eachData.Name,
             eachData.Email
            )
        }}>Edit</button>

        </Link>
      </td>
      <td>
      <button className='btn-denger' onClick={()=>{handele(eachData.id)}}>Delate</button>

      </td>


    </tr>
    
  </tbody>
    
    </>
  })
  
  
  }

  


</table>



    </>
  )
}

export default Read*/
import axios from 'axios';
import React,{useEffect,useState} from 'react'
import {Link, useNavigate} from "react-router-dom"
import Read from "./Read";


const Update = () => {

    const history= useNavigate()

     const [id, setid] = useState(0);
     const [name, setname] = useState("");
     const [email, setemail] = useState("")
     const [Data, setData] = useState([])

  useEffect(() => {

    setid(localStorage.getItem("id"));
    setname(localStorage.getItem("email"));
    setemail(localStorage.getItem("name"));
    console.log(name)


  }, [])
  
const hsnup=(e)=>{
  e.preventDefault();
        axios.put(`https://6408099b2f01352a8a8903f1.mockapi.io/Crud01/${id}`,{
        Name: name,
        Email: email,
         }).then(()=>{
            history("/read")
        })
}
/*function getData(){
  const res = axios.get("https://6408099b2f01352a8a8903f1.mockapi.io/Crud01");
  console.log(res)
}
 const rese = axios.get(`https://6408099b2f01352a8a8903f1.mockapi.io/Crud01/${4}`);
 console.log(rese);
 setData(rese.data)*/

 function getData(){
  axios
  .get(`https://6408099b2f01352a8a8903f1.mockapi.io/Crud01/${id}`)
 .then((res)=>{
   console.log(res.data);
   setData(res.data)
 })
}
useEffect(() => {
  getData();
}, [])
 console.log(id)

 console.log( Data.cument)
  return (
    <>
        <h2>Hey this is All the cument{name} on this post</h2>
      

<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">{name}</th>
      <th scope="col">cument</th>
      <th scope="col">Clean cument</th>
    </tr>
  </thead>

    {

 
        <tbody>

    <tr>
      <th scope="row">1</th>
      <td>{Data.Name}</td>
      <td>
      {Data.cument}
      </td>
      <td>
<button type="submit" className="btn btn-primary m-2" >Delate</button>
  
    </td>
    </tr>
    
  </tbody>
        
 
 
    }
    
</table>
    </>
  )
}

export default Update