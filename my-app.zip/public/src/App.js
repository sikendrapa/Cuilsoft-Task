import Create from "./Component/Create";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Read from "./Component/Read";
import Update from "./Component/Update";
import Cument from "./Component/Cument";
import Showcument from "./Component/Showcument";



function App() {
  return (
    <>
     <BrowserRouter>
      <Routes>
        <Route exact path="/" element={<Create/>}></Route>
        <Route exact path="/read" element={<Read/>}></Route>
        <Route exact path="/update" element={<Update/>}></Route>
        <Route exact path="/cument" element={<Cument/>}></Route>
        <Route exact path="/showcument" element={<Showcument/>}></Route>




      </Routes>
    </BrowserRouter>
    </>
  );
}

export default App;
